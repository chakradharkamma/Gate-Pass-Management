const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs'); 
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
const downloadDir = path.join(__dirname, 'downloads');
if (!fs.existsSync(downloadDir)) {
  fs.mkdirSync(downloadDir);
}
let gatePasses = [];
app.get('/', (req, res) => {
  res.render('login');
});
app.post('/login', (req, res) => {
  const { role } = req.body;
  if (role === 'student') return res.redirect('/student-dashboard');
  if (role === 'rector') return res.redirect('/rector-dashboard');
  if (role === 'admin') return res.redirect('/admin-dashboard');
  res.status(400).send('Invalid role.');
});
app.get('/student-dashboard', (req, res) => {
  res.render('student-dashboard');
});
app.post('/apply-gatepass', (req, res) => {
  const { name, enrollment_number, where_to_visit, reason, fromDate, toDate, fromTime, toTime } = req.body;
  if (!name || !enrollment_number || !where_to_visit || !reason || !fromDate || !toDate || !fromTime || !toTime) {
    return res.status(400).send('All fields are required.');
  }
  gatePasses.push({
    id: gatePasses.length + 1,
    name,
    enrollment_number,
    where_to_visit,
    reason,
    fromDate,
    toDate,
    fromTime,
    toTime,
    status: 'Pending',
  });
  res.render('success', { message: 'Gate pass request submitted successfully!' });
});
app.get('/rector-dashboard', (req, res) => {
  res.render('rector-dashboard', { gatePasses });
});
app.get('/approve-gatepass/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const gatePass = gatePasses.find(gp => gp.id === id);
  if (!gatePass) return res.status(404).send('Gate pass not found.');
  gatePass.status = 'Approved';
  res.redirect('/rector-dashboard');
});
app.get('/reject-gatepass/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const gatePass = gatePasses.find(gp => gp.id === id);
  if (!gatePass) return res.status(404).send('Gate pass not found.');
  gatePass.status = 'Rejected';
  res.redirect('/rector-dashboard');
});
app.get('/admin-dashboard', (req, res) => {
  res.render('admin-dashboard', { gatePasses });
});
app.get('/download-gatepass/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const gatePass = gatePasses.find(gp => gp.id === id);
  if (!gatePass) return res.status(404).send('Gate pass not found.');
  if (gatePass.status !== 'Approved') {
    return res.status(400).send('Gate pass is not approved.');
  }
  const fileContent = `Gate Pass for: ${gatePass.name}\nEnrollment Number: ${gatePass.enrollment_number}\nWhere to Visit: ${gatePass.where_to_visit}\nReason: ${gatePass.reason}\nFrom Date: ${gatePass.fromDate}\nTo Date: ${gatePass.toDate}\nFrom Time: ${gatePass.fromTime}\nTo Time: ${gatePass.toTime}\nStatus: Approved`;
  const filePath = path.join(downloadDir, `gatepass_${gatePass.id}.txt`);
  fs.writeFileSync(filePath, fileContent);
  res.download(filePath, `gatepass_${gatePass.id}.txt`, (err) => {
    if (err) {
      console.error('File download error:', err);
      res.status(500).send('Error downloading gate pass.');
    } else {
      fs.unlinkSync(filePath); 
    }
  });
});

app.use((req, res) => {
  res.status(404).send('Page not found.');
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
